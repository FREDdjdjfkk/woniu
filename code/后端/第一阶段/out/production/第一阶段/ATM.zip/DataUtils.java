package ATM;

import java.util.ArrayList;
import java.util.List;

public class DataUtils {
    static List<User> users=new ArrayList<>();
    public int getindex(String username) {
        int index=-1;
        for (User i : users) {
            if (i.getUsername().equals(username)) {
                index=users.indexOf(i);
            }
        }
        return index;
    }

}
